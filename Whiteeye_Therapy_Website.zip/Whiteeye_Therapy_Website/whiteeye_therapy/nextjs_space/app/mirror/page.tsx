import { MirrorInterface } from '@/components/whiteeye/mirror-interface'

export const dynamic = 'force-dynamic'

export default function MirrorPage() {
  return <MirrorInterface />
}
